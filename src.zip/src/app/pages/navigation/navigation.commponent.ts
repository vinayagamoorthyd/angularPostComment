import { Component } from '@angular/core';


@Component({
  templateUrl: `./view.navigation.html`
})
export class navigation  {

}
