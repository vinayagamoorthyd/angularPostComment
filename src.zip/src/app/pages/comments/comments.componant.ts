import { Component } from '@angular/core';
import { ApiService} from './../../services/api/api.service';


@Component({
  templateUrl: `./view.comments.html`
})
export class commentsPage  {
  private comments:any={};
  private displayForm:boolean=false;
  private formcid:number;
  public users:any;

  constructor(public api:ApiService) {
    this.comments=[
      {
        'title':'Angular Feature',
        'comment':'Angular Feature',
        'date':'10/08/2017',
        '_id':'01'
      },
      {
        'title':'Angular Feature',
        'comment':'Angular Feature',
        'date':'13/08/2017',
        '_id':'02'
      },
      // {
      //   'title':'Angular Feature',
      //   'content':'Angular Feature',
      //   'date':'18/08/2017',
      //   '_id':'03'
      // },
      // {
      //   'title':'Angular Feature',
      //   'content':'Angular Feature',
      //   'date':'20/08/2017',
      //   '_id':'04'
      // },
      // {
      //   'title':'Angular Feature',
      //   'content':'Angular Feature',
      //   'date':'25/08/2017',
      //   '_id':'05'
      // },
]
 }
getnewData(){
  this.api.rest().then(respon=>{
    this.userctrl=rest;
  })
}
fetchData(){
     this.api.test().then(res=>{
       this.users=res;
       console.log('res',res);
     });
}

 insertData(data:any){
   (this.comments).push(data);
 }

}
