import { Component } from '@angular/core';


@Component({
  template: `
    <input type="text" placeholder="name" />
    <input type="text" placeholder="password"/>
    <p >{{counter}}</p>

  `
})
export class loginPage  {
  
}
