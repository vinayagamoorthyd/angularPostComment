import{ Injectable } from '@angular/core';
import { Http , Headers, RequestOptions  } from '@angular/http';

@Injectable()
export class ApiService{
  private result:any;
constructor(public http:Http){

}
rest(){
  return new Promise ((resolve,reject)=>{
    this.maxlen();
    setTimeout(()=>{
      resolve(this.result);
    },200)
  });
}
maxlen(){
  this.http.get('./datajson.json').subscribe(respon=>{
    this.result=JSON.parse(respon['data']);
  });
}
test(){
    return new Promise((resolve,reject)=>{
      this.subs();
       setTimeout( ()=>{
         resolve( this.result );
        },100 ) });
}

  subs(){
     this.http.get('http://192.168.1.20:1028/users/test').subscribe(res=>{
      this.result=JSON.parse( res['_body'] );
      //console.log(res['_body']);
    });
  }
}
